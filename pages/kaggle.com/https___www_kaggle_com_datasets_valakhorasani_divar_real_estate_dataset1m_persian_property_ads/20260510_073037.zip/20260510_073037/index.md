# Visited: https://www.kaggle.com/datasets/valakhorasani/divar-real-estate-dataset1m-persian-property-ads
**Time:** Sun May 10 07:30:45 UTC 2026

## Screenshot
![Screenshot](./screenshot.png)

## Raw HTML
[page.html](./page.html)

## Downloaded Media (0 files)
_No media files downloaded_

## Other Links
- [/static/assets/app.css?v=a53f951c511cf82e](/static/assets/app.css?v=a53f951c511cf82e)
- [/static/assets/app.js?v=8d2601a1dfa6e95c](/static/assets/app.js?v=8d2601a1dfa6e95c)
- [/static/assets/runtime.js?v=7ebfa52406451e3d](/static/assets/runtime.js?v=7ebfa52406451e3d)
- [/static/assets/vendor.js?v=16e57cdf2074cbfa](/static/assets/vendor.js?v=16e57cdf2074cbfa)
- [/static/json/manifest.json](/static/json/manifest.json)
- [https://accounts.google.com/gsi/client](https://accounts.google.com/gsi/client)
- [https://apis.google.com](https://apis.google.com)
- [https://apis.google.com/js/api.js](https://apis.google.com/js/api.js)
- [https://fonts.googleapis.com/css2?family=Google+Symbols:FILL@0..1&display=block](https://fonts.googleapis.com/css2?family=Google+Symbols:FILL@0..1&display=block)
- [https://fonts.googleapis.com/css?family=Inter:400,400i,500,500i,600,600i,700,700i&display=swap](https://fonts.googleapis.com/css?family=Inter:400,400i,500,500i,600,600i,700,700i&display=swap)
- [https://fonts.gstatic.com](https://fonts.gstatic.com)
- [https://stats.g.doubleclick.net](https://stats.g.doubleclick.net)
- [https://storage.googleapis.com](https://storage.googleapis.com)
- [https://www.google-analytics.com](https://www.google-analytics.com)
- [https://www.googletagmanager.com/gtag/js?id=G-T7QHS60L4Q](https://www.googletagmanager.com/gtag/js?id=G-T7QHS60L4Q)
- [https://www.kaggle.com/datasets/valakhorasani/divar-real-estate-dataset1m-persian-property-ads](https://www.kaggle.com/datasets/valakhorasani/divar-real-estate-dataset1m-persian-property-ads)

## Stats
- Links: 17
- Media: 0
